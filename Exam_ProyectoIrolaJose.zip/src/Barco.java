/*
Subclase hijo de Acuatico
*/

/**
 * @author josea
 */
public class Barco extends Acuatico {
    public String PrenderMotor(){
        return"Estas en el metodo Prender Motor de la subclase Barco ";
    }
}
