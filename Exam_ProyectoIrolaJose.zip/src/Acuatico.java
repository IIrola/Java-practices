/*
Hijo de vehiculo
 */

/**
 *
 * @author josea
 */
public class Acuatico extends Vehiculo{
    public String NombreAcua="";
    //Metodo
    public String Navegar(){
        return"Estas en el metodo navegar de la subclase Acuatico ";
    }
}
