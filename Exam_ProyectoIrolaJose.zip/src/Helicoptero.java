/*
Subclase hijo de Aereo
 */

/**
 *
 * @author josea
 */
public class Helicoptero extends Aereo {
    public String EncenderHelices(){
        return"Estas en el metodo Encender helices de la subclase Helicoptero ";
    }
}