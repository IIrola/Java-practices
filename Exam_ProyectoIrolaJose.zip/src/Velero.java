/*
Subclase hijo de Acuatico
*/

/**
 * @author josea
 */
public class Velero extends Acuatico {
    public String IzarVelas(){
        return"Estas en el metodo Izar velas de la subclase Velero ";
    }
}
