/*
Clase padre
 */

/**
 * @author josea
 */
public class Vehiculo {
    public int modeloVehiculo;
    public String nombreVehiculo="";
    
    //Metodos
    public String Transportar(){
        return "Estas en el metodo Transportar de la clase vehiculo ";
    }
}
