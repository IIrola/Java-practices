/*
Hijo de vehiculo
 */

/**
 *
 * @author josea
 */
public class Aereo extends Vehiculo{
    public String NombreAero="";
    //Metodo
    public String Volar(){
        return"Estas en el metodo Volar de la subclase Aereo ";
    }
}