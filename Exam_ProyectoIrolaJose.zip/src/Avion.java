/*
subclase hijo de Aereo
*/

/**
 * @author josea
 */
public class Avion extends Aereo{
    public String BajarTrendeAterrizaje(){
        return"Estas en la clase Bajar tren de aterrizaje de la subclase avion ";
    }
}
